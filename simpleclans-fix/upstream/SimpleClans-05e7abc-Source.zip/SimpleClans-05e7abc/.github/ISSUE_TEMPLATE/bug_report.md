---
name: Bug report
about: Create a report to help us improve
title: ''
labels: bug
assignees: ''

---

**Describe the bug**
A clear and concise description of what the bug is.

**To Reproduce**
Steps to reproduce the behavior:
1. Run the command '...'
2. Click on a mob '....'
3. See error

**Expected behavior**
A clear and concise description of what you expected to happen.

**Screenshots**
If applicable, add screenshots to help explain your problem.

**Software (please complete the following information):**
 - Server: [e.g. Spigot 1.12]
 - Plugin version [e.g. 2.12.1]

**Additional context**
Add any other context about the problem here.
