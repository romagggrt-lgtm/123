# Все переданные PNG и звуки

Это файлы из актуального Fabric, а не новые перерисовки. У исходных копий проверяется SHA256. Все предметные/блочные модели и blockstates находятся рядом в assets-original/assets/smplore.

У луча, оболочки купола, меню и HUD отдельной custom PNG в моде нет: это код/ванильные assets. Геометрия и цвета в effects/ и основных документах. Эндермит включён как compatibility-ассет, не как готовый новый моб.

[Общий лист PNG](TEXTURES_ATLAS.png) · [Галерея и крафты](GALLERY_AND_RECIPES.html)

| Файл | Размер | SHA256 |
|---|---|---|
| [magnetite_core_bottom.png](assets-original/assets/smplore/textures/block/magnetite_core_bottom.png) | 32×32 | `2925203c9a41aad1dadd0c6708cc73ff918699eedd3725cde51d7028748c3351` |
| [magnetite_core_front.png](assets-original/assets/smplore/textures/block/magnetite_core_front.png) | 32×32 | `6fcc4d6098ad5a695e3dee912ad5440f4108678f386ee6be5e6cfe086db76892` |
| [magnetite_core_side.png](assets-original/assets/smplore/textures/block/magnetite_core_side.png) | 32×32 | `6c36976f2140489b0a47e2a142e6d9b835db4b747e571d4e70222e2c1d4dd903` |
| [magnetite_core_top.png](assets-original/assets/smplore/textures/block/magnetite_core_top.png) | 32×32 | `5b2bf128bbd9ecc99f201f74e46bebc9b78347a63940df66acf5919f24c8dc52` |
| [void_absorber_bottom.png](assets-original/assets/smplore/textures/block/void_absorber_bottom.png) | 32×32 | `8e2448f35dcecc7a8a2e66ec0ad8577738e78e13d57a3b9e618fa51edf10888d` |
| [void_absorber_front.png](assets-original/assets/smplore/textures/block/void_absorber_front.png) | 32×32 | `cdc949a8f482bec1ff01b24d3ad933425464e0ce98bb89080930690270b8ccc3` |
| [void_absorber_side.png](assets-original/assets/smplore/textures/block/void_absorber_side.png) | 32×32 | `0f28383d1315b990542b7903c08f03c9f4e1313acae05cde3562b7c5f9663231` |
| [void_absorber_top.png](assets-original/assets/smplore/textures/block/void_absorber_top.png) | 32×32 | `bcbd6cfb87fd962decd20271ee84de97a9fafde11b5885081f5d4b11ba175717` |
| [void_alarm_bottom.png](assets-original/assets/smplore/textures/block/void_alarm_bottom.png) | 32×32 | `f4021a45e18154a505e634d7042bcc8607b59ab206eb3380ee4802f2ae4e62cc` |
| [void_alarm_front.png](assets-original/assets/smplore/textures/block/void_alarm_front.png) | 32×32 | `62867ae7804d7a3771c4014d59cd545dfa0a1cb8cab9651fd026458873c81421` |
| [void_alarm_side.png](assets-original/assets/smplore/textures/block/void_alarm_side.png) | 32×32 | `0c6fff6aed000a1e019e8108b3b01fd6bc2b60ca6a66a62e6033f4b4f40fa5cc` |
| [void_alarm_top.png](assets-original/assets/smplore/textures/block/void_alarm_top.png) | 32×32 | `33e3b9a7a6612998cdc4f4552d30ce8e6e996dfbbad9864b6dcd2a26b25d35ec` |
| [void_siren_bottom.png](assets-original/assets/smplore/textures/block/void_siren_bottom.png) | 32×32 | `871fc0d182f59364875d96293d5eec4c68f5ecaa26cfd3d2e225f715fb3c3c4d` |
| [void_siren_front.png](assets-original/assets/smplore/textures/block/void_siren_front.png) | 32×32 | `6f3d230958943f1a97ada43274e779026ab579254159244ee519011bbfa410dc` |
| [void_siren_side.png](assets-original/assets/smplore/textures/block/void_siren_side.png) | 32×32 | `63a0b9dfcf735475a5066f0e179c2547e0d7d74be931a04682f03598d1c0738d` |
| [void_siren_top.png](assets-original/assets/smplore/textures/block/void_siren_top.png) | 32×32 | `e57ae2068bdda94b9e474fca2869d2af1b85edc2b0b2ccb5d5222ef1bb972f6c` |
| [enriched_endermite.png](assets-original/assets/smplore/textures/entity/enriched_endermite.png) | 128×128 | `2ae3a5205e322798a303f39f273647ed38b029cf2a8e92cd25d1970966a5ffef` |
| [liquid_void.png](assets-original/assets/smplore/textures/item/liquid_void.png) | 16×16 | `de781e2e2aa33931bcb975ab47a7f544aa22f2b7e54e949ea98cc42e7cc54c6c` |
| [void_breath.png](assets-original/assets/smplore/textures/item/void_breath.png) | 16×16 | `4689727d487c96158034a19e3bbf074e67d6e83b99a0fcd560b5f4b976d08bfa` |
| [voidometer.png](assets-original/assets/smplore/textures/item/voidometer.png) | 32×32 | `79bff48c7b6f2e842f53efa4a9a6a58853fb2b1bbda1907369f811a9154dd112` |

## Фактические аудиофайлы

| Файл | Секунд | Каналы |
|---|---:|---:|
| [alarm.ogg](assets-original/assets/smplore/sounds/alarms/alarm.ogg) | 11.100 | 1 |
| [classic.ogg](assets-original/assets/smplore/sounds/alarms/classic.ogg) | 12.000 | 1 |
| [evacuation.ogg](assets-original/assets/smplore/sounds/alarms/evacuation.ogg) | 50.200 | 1 |
| [exchange.ogg](assets-original/assets/smplore/sounds/alarms/exchange.ogg) | 12.000 | 1 |
| [frontier.ogg](assets-original/assets/smplore/sounds/alarms/frontier.ogg) | 29.000 | 1 |
| [mechanical.ogg](assets-original/assets/smplore/sounds/alarms/mechanical.ogg) | 12.000 | 1 |
| [pulse.ogg](assets-original/assets/smplore/sounds/alarms/pulse.ogg) | 12.000 | 1 |
| [watch.ogg](assets-original/assets/smplore/sounds/alarms/watch.ogg) | 9.600 | 1 |
| [meter_click.ogg](assets-original/assets/smplore/sounds/meter_click.ogg) | 0.035 | 1 |
